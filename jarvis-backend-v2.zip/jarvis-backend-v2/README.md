# JARVIS AI Backend v2.0

This is an expanded Cloudflare Worker backend for the supplied JARVIS APK. It adds optional persistent memory, web search and text-to-speech, while keeping the chat/image/video routes. It is source code only: it has **not** been deployed, connected to provider accounts, or integrated into a rebuilt Android APK.

## Included API

| Route | Purpose | Required configuration |
|---|---|---|
| `GET /health` | Health/version check | None |
| `GET /api/capabilities` | Reports enabled features | Optional auth token |
| `POST /api/chat` | Gemini chat; supports history and image/audio attachments | `GEMINI_API_KEY` |
| `POST /api/image` | Text-to-image | Gemini image-model access and `GEMINI_API_KEY` |
| `POST /api/tts` | Text-to-speech audio | TTS model access and `GEMINI_API_KEY` |
| `POST /api/search` | Web search | `TAVILY_API_KEY` |
| `GET/POST/DELETE /api/memory` | Persistent user memory | KV binding `JARVIS_KV` |
| `POST /api/video` | Generic Kling-compatible task submission adapter | Provider URL/key and matching schema |
| `GET /api/video/{id}` | Video task status adapter | Provider status URL/key |

All protected routes accept optional `Authorization: Bearer <JARVIS_API_TOKEN>` when `JARVIS_API_TOKEN` is configured. Memory is partitioned by `x-jarvis-user` header or `userId` body field. Do not treat a user ID as authentication.

## Provider setup

1. Create a Cloudflare account and a Worker.
2. Create a KV namespace named for JARVIS memory and rate limiting. Bind it in Worker settings with variable name `JARVIS_KV`.
3. Set Worker secrets:
   - `GEMINI_API_KEY` — Google AI Studio key.
   - `TAVILY_API_KEY` — optional web-search key.
   - `JARVIS_API_TOKEN` — optional shared API token (the supplied APK may not send it; test before enabling).
   - `KLING_API_KEY`, `KLING_API_URL`, `KLING_STATUS_URL` — only after confirming the exact API contract for the video provider account.
4. Set variables as needed: `GEMINI_MODEL` (default `gemini-3.8-flash`), `GEMINI_IMAGE_MODEL` (default `gemini-3.1-flash-image`), `GEMINI_TTS_MODEL` (default `gemini-2.5-flash-preview-tts`), `RATE_LIMIT_PER_HOUR`, `ALLOWED_ORIGINS`.
5. Deploy using `npm install` then `npm run deploy`, or paste `src/index.js` into the Cloudflare Worker editor and configure bindings/secrets there.
6. Test `GET https://YOUR-WORKER.workers.dev/health` and `GET /api/capabilities`.

Cloudflare free plans have quotas. Current Google pricing lists Gemini 3.8 Flash with a free tier, but image generation and some third-party search/video services may require paid access or have separate limits. A free Worker does not make model inference free or unlimited. Check current pricing and account eligibility before enabling usage. See https://ai.google.dev/gemini-api/docs/pricing.

## Request examples

Chat:

```json
{
  "userId": "local-install-1",
  "prompt": "Explain photosynthesis simply",
  "history": [{"role":"user","text":"Hi"},{"role":"assistant","text":"Hello!"}]
}
```

Save a memory:

```json
{"userId":"local-install-1","text":"The user prefers concise explanations."}
```

Search:

```json
{"query":"Latest Android security update information"}
```

TTS:

```json
{"text":"Hello. I am JARVIS.","voice":"Kore"}
```

Image:

```json
{"prompt":"A cinematic futuristic blue AI assistant interface"}
```

## Important integration gaps

- The existing APK is compiled (`com.royal.jarvis`) and no Android Studio source project was supplied. This backend cannot add buttons, wire new routes into the app, or produce a rebuilt APK.
- The inspected APK exposes chat, video studio and backend URL configuration. It did not expose an image studio route in the APK strings inspected. Image, search, memory and TTS endpoints therefore need Android UI/client work before they are accessible in the app.
- Video is an adapter only. Provider URL, authentication, request body, status response and media upload rules must match the user's actual video provider plan. Do not assume a Kling endpoint/schema.
- Audio understanding is available through `/api/chat` inline audio attachments if supported by the configured Gemini model/account. TTS is a separate endpoint and requires app-side audio playback.
- Persistent memory requires a KV namespace binding. Without it, the endpoint explicitly reports that memory is unavailable.
- Web search requires a Tavily key. Search results are returned to the app; they are not automatically cited/grounded in chat unless the Android client submits the search results in a follow-up prompt.
- Email, calendar, phone calls, messages, payments, arbitrary Android device control and autonomous background execution are not implemented. These require OAuth integrations, Android runtime permissions, user confirmation, and app-side code. Do not expose dangerous actions as unrestricted AI commands.

## Security checklist

- Keep all provider keys in Worker secrets, never in the APK.
- Use authentication before public release. A shared bearer token is not ideal for a distributed app; production should use per-user authentication/OAuth.
- Bind KV for rate limiting and memory; set restrictive CORS where applicable.
- Configure spending/usage limits with every provider.
- Add privacy-safe logs, user data deletion controls, abuse protection and explicit confirmation for consequential actions.
- Do not use the default `userId` for a multi-user public deployment. Require a verified account ID from an authenticated session.

## Local checks

Run `npm test` to execute the built-in Node tests. Tests cover route behavior and missing configuration; they do not test live provider credentials or a deployed Worker.
