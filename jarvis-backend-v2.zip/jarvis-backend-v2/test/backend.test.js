import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../src/index.js';

const request = (path, method = 'GET', payload, headers = {}) => new Request(`https://jarvis.test${path}`, {
  method,
  headers: { ...(payload ? { 'content-type': 'application/json' } : {}), ...headers },
  body: payload ? JSON.stringify(payload) : undefined
});

test('health endpoint returns backend version', async () => {
  const response = await worker.fetch(request('/health'), {}, {});
  assert.equal(response.status, 200);
  const data = await response.json();
  assert.equal(data.version, '2.0.0');
});

test('configured API token is enforced', async () => {
  const response = await worker.fetch(request('/api/capabilities'), { JARVIS_API_TOKEN: 'secret' }, {});
  assert.equal(response.status, 401);
});

test('capabilities accurately report optional integrations', async () => {
  const response = await worker.fetch(request('/api/capabilities', 'GET', null, { authorization: 'Bearer secret' }), { JARVIS_API_TOKEN: 'secret', GEMINI_API_KEY: 'x' }, {});
  assert.equal(response.status, 200);
  const data = await response.json();
  assert.equal(data.capabilities.chat, true);
  assert.equal(data.capabilities.webSearch, false);
  assert.equal(data.capabilities.persistentMemory, false);
});

test('memory requires KV binding instead of pretending to persist', async () => {
  const response = await worker.fetch(request('/api/memory', 'POST', { text: 'remember this' }), {}, {});
  assert.equal(response.status, 500);
  const data = await response.json();
  assert.match(data.error, /Persistent memory is not enabled/);
});

test('chat reports missing Gemini credentials clearly', async () => {
  const response = await worker.fetch(request('/api/chat', 'POST', { prompt: 'hello' }), {}, {});
  assert.equal(response.status, 500);
  const data = await response.json();
  assert.match(data.error, /GEMINI_API_KEY/);
});
