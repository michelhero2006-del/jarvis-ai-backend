# Android integration contract (source project required)

The supplied `app-debug.apk` is compiled output. This guide records the HTTP contract a developer can wire into the original Android Studio project or a clean replacement app.

## Base URL

Save the deployed Worker URL in the app's existing Backend URL setting, e.g. `https://<worker-subdomain>.workers.dev`.

## Chat

`POST /api/chat` with `Content-Type: application/json`:

```json
{
  "userId": "stable-install-or-authenticated-user-id",
  "prompt": "What can you do?",
  "history": [
    {"role":"user","text":"Hello"},
    {"role":"assistant","text":"Hello. How can I help?"}
  ]
}
```

Read `reply` (the backend also returns `response`, `message`, and `text` for compatibility). For image/audio understanding, add `attachments` entries with `mimeType` and base64 `data`.

## Image generation

`POST /api/image` with `{"prompt":"..."}`. Decode `imageBase64` using Android Base64 and display/save according to user choice. Do not assume image generation is free; check provider quota.

## Web search

`POST /api/search` with `{"query":"..."}`. Show result titles, URLs and snippets. For grounded chat, append the returned answer/results to a follow-up chat prompt and clearly label them as search results.

## Persistent memory

- `GET /api/memory` — retrieve `{items:[...]}`
- `POST /api/memory` — save `{"text":"...","userId":"..."}`
- `DELETE /api/memory` — delete the current user's memory

Use a verified account identifier if accounts exist. Do not use a display name or email as a security boundary. Ask before saving sensitive personal information and provide a clear delete-memory control.

## Text-to-speech

`POST /api/tts` with `{"text":"...","voice":"Kore"}`. The response contains base64 audio and MIME type. The app must decode and play it; PCM may need WAV wrapping/resampling depending on Android playback implementation.

## Video

The existing app already has a video studio according to inspection. Keep its existing request/response contract and configure the provider adapter to match the actual account's API docs. The generic endpoint in this backend is not proof that any specific Kling API schema will work.

## Safety and permissions

- Ask before sending messages, making calls, purchasing, deleting files, changing settings or sharing location.
- Use Android runtime permissions for microphone, camera, notifications and files as needed.
- Android app/device automation is not enabled by a server endpoint. It requires a native implementation, user-granted permissions and Android accessibility/service restrictions.
- Never package Gemini, search, video or other provider secrets in the APK.
